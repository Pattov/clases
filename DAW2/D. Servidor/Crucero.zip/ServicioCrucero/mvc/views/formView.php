<html>
    <head>
      <meta charset="UTF-8">
        <title>{titulo}</title>
        <style>
             label {
        display: inline-block;
        width: 20ch;
        text-align: right;
        color:white;
      }
      .rounded-input {
  padding:10px;
  border-radius:10px;
  color:black;
}
body{
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: black;
    
}
button{
  background-color: white;
  color: black;
  border: 2px solid #4CAF50; 
  padding: .6em;
  cursor:pointer; 
  color:green;
  border-radius: 20px;
}
h1{
    color:white;
}

    </style>
    </head>
    <body>
        <div>
            {formulario}
        </div>
    </body>
</html>
