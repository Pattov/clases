<html>
    <head>
        <title>{titulo}</title>
        <style>
            h1{
                text-align: center;
            }
        </style>
    </head>
    <body>
        <h1>Reserva ya tu crucero</h1>
        <div>
            <a href="index.php?controller=login">Haz login</a>
            <br>
            <a href="index.php?controller=register">Regístrate</a>
            <br>
          
        </div>
    </body>
</html>
