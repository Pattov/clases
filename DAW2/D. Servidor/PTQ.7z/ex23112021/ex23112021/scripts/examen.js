function jugador() {
    // creo variable jugador y cojo el valor del formulario
    let usuario = document.getElementById("jugador");
    let jugadas = [] //Añado los puntos de jugada
    //creo la estructura json propiedad:valor -> nombre:usuario
    let jugador = {
        'nombre': usuario,
        'jugadas': jugadas
    }
    //lo paso a localStorage
    localStorage.setItem(usuario,JSON.stringify(jugador))
}

let figuras = [
    {
        id: "futbol",
        ruta: "imagenes/futbol.png",
        puntos: 20
    },
    {
        id: "basket",
        ruta: "imagenes/basket.png",
        puntos: 10
    },
    {
        id: "tenis",
        ruta: "imagenes/tenis.jpg",
        puntos: 5
    },
    {
        id: "rugby",
        ruta: "imagenes/rugby.png",
        puntos: 2
    }

]

document.getElementById("btn").onclick = jugador();