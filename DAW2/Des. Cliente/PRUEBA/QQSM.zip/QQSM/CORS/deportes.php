<?php
readfile('https://github.com/Arquisoft/Trivial2b/blob/master/extract/src/main/java/es/uniovi/asw/trivial/resources/PreguntasDeporte.json');
?>