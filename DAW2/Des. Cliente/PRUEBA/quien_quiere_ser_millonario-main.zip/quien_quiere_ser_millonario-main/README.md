# quien_quiere_ser_millonario
Aplicación Front-end tipo Quien Quiere ser Millonario

Desarrolado como proyecto final del Diplomado de desarrollo Front-end

HTML-CSS-SASS-JS
